var button = document.getElementById('togle'); // Assumes element with id='button'

button.onclick = function() {
    var div = document.getElementById('reading-progress-fill');
    if (div.style.display !== 'none') {
        div.style.display = 'none';
    }
    else {
        setTimeout(() => { div.style.display = 'block'; }, 380);
    }
};